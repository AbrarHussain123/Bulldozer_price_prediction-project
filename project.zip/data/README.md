# Data Folder

This folder contains all your datasets. The following files will be stored here 

1. All files with a .csv extension
2. All images for a Computer Vision task
3. All audio files for an audio task

